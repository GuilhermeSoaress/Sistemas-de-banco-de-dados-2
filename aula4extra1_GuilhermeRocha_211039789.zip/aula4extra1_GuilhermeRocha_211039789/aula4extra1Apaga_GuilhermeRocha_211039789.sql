﻿-- -------- < aula4extra1 > --------
--
--                    APAGA (DML)
--
-- Data Criacao ...........: 04/09/2023
-- Autor(es) ..............: Guilherme Soares Rocha
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4extra1
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
-- 
--
-- ----------------------------------------------------------
use aula4;

DROP TABLE CIDADE;
DROP TABLE ESTADO;